#include "rssFeeder.h"

RSSFeeder::RSSFeeder(const std::string &name) : Publisher(name) {

}

RSSFeeder::~RSSFeeder() {

}
